void convertInches(int inches, int *yards, int *feet, int *inch){
   
   *yards = inches / 36;
   inches %= 36;

   *feet = inches / 12;
   inches %= 12;

   *inch = inches;
   
}
