/** CpSc 2100

    Sample solution to lab 3.

    String functions:
       mystrlen()
       mystrupper()
       mystrcmp()
**/

#include <stdio.h>
#include <stdlib.h>
#include "mystrings.h"

/** mystrlen **/
int mystrlen(char *s1)
{
   /** STUBBED -- insert new code here **/
   return(0);
}

/** mystrupper **/
char *mystrupper(char *s1)
{
   /** STUBBED -- insert new code here **/
   return(s1);
}

/** mystrcmp **/
int mystrcmp(char *s1, char *s2)
{
   /** STUBBED -- insert new code here **/
   return(0);
}
