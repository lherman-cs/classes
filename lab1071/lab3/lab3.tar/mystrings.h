/* Function Prototype Statements */
int  mystrlen(char *);
char *mystrupper(char *);
int  mystrcmp(char *, char *);

