/*
   CPSC 1070 
   Lab 7
   odomoter.h
*/

#include <iostream>
#include <string>>
#include "odometer.h"

using namespace std;
    
/**
  The default constructor and the destructor have been
  implemented for you.  You must implement all other methods.
  Be sure to use the scope resolution operator ::
**/

Odometer::Odometer()
{
   miles = 0;
}

Odometer(int initialMiles)
{

}

Odometer::~Odometer()  
{
   cout << "In the destructor.\n";
}

void setMiles(int initialMiles) 
{
       
}

int getMiles()      
{
   
}

void increment()
{
   
}

void decrement()
{
   
}

string warrantyInfo()
{
   /*  declare a string using the keyword "string".  
       you can assign a quoted string to the string variable
       e.g.
       string  str;
       str = "Go Tigers";
   */

} 

void print()
{
   
}
