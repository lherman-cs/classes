#include "image.h"

/** newImage 

    Create and initialize a new image_t.

    Prototype:
       image_t *newImage(int columns, int rows, int brightness);
 
    where
       columns: number of pixel columns in new PPM image
       rows:    number of pixel rows in new PPM image
       brightness:  pixel brightness (0-255)

    Return value:
       Pointer to newly allocated and initialized image_t
**/
image_t *newImage(int columns, int rows, int brightness) 
{

   /** STUBBED **/

   return(NULL);
}
