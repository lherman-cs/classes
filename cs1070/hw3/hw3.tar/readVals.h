#ifndef READVALS_H
#define READVALS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "image.h"

/** prototype statements **/
color_t readColor(FILE *fp);

#endif
