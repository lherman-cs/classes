/** duotone.c 

    Convert an input PPM image to a duotone 

    Prototype:
       image_t *duotone(image_t *inImage, pixel_t tint);

       where
          inImage: pointer to the image_t of the input image,
          tint: red, green, blue values for the tint

       Return value: 
          Pointer to newly created image_t for the output image.

**/
#include "image.h"

image_t *duotone(image_t *inImage, color_t tint) 
{
   /* STUBBED */


   return(NULL);
}
